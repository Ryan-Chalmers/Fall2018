#ifndef INPUT_H
#define INPUT_H

char *get_dir(void);

#endif // INPUT_H
