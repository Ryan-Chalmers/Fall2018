#ifndef JOB_H
#define JOB_H

static int jobid = 1;
int create_job(const char *);

#endif
